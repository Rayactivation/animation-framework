from __future__ import absolute_import

from simple_af.launcher import launch

launch()